import { world, system, ItemComponentTypes } from "@minecraft/server";

const XP_COST = 20; // levels
const LORE_TAG = "§7Keep Inventory";
const ALTAR_ID = "keepinv:altar";

/**
 * Checks if an item already has the Keep Inventory "enchant" applied.
 * Detected via lore text, since Bedrock has no API for registering
 * true custom enchantments.
 */
function hasKeepInventory(itemStack) {
  if (!itemStack) return false;
  return itemStack.getLore().includes(LORE_TAG);
}

// Using beforeEvents here (not afterEvents) is required: if the held item
// is a placeable block, Minecraft will otherwise try to place it against
// the altar as normal block-placement behavior, since afterEvents fires
// too late to stop that. Cancelling in the before-event blocks placement
// (or any other default use-action) for every item type, block or not.
// beforeEvents are read-only, so the actual work is deferred to
// system.run() on the next tick, after the read-only window closes.
world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
  const { block, player, itemStack } = event;

  if (block.typeId !== ALTAR_ID) return;

  // Cancel unconditionally for this block so nothing (block placement,
  // item use-action, etc.) happens before our own logic runs.
  event.cancel = true;

  system.run(() => enchantItem(player, itemStack));
});

function enchantItem(player, itemStack) {
  if (!itemStack) {
    player.sendMessage("§cHold an item to enchant it with Keep Inventory.");
    return;
  }

  if (hasKeepInventory(itemStack)) {
    player.sendMessage("§eThat item already has Keep Inventory.");
    return;
  }

  if (player.level < XP_COST) {
    player.sendMessage(`§cYou need at least ${XP_COST} XP levels to do this.`);
    return;
  }

  const slotIndex = player.selectedSlotIndex;
  const typeId = itemStack.typeId;
  const amount = itemStack.amount;

  // Save what we need to carry over before the item gets overwritten.
  const nameTag = itemStack.nameTag;
  const lore = itemStack.getLore();
  const durabilityComp = itemStack.getComponent(ItemComponentTypes.Durability);
  const damage = durabilityComp ? durabilityComp.damage : undefined;
  const enchantableComp = itemStack.getComponent(ItemComponentTypes.Enchantable);
  const enchantments = enchantableComp ? enchantableComp.getEnchantments() : [];

  // minecraft:keep_on_death can only be attached via /give or /replaceitem's
  // components JSON argument — there's no script-side setter for it. This
  // necessarily creates a brand new vanilla stack in the slot, wiping any
  // enchantments/lore/name that were on it, so we reapply those from our
  // saved copies immediately after. Durability doesn't need reapplying in
  // script at all: the numeric "data" argument in /replaceitem sets the
  // item's damage value directly, so we just pass it straight through.
  const componentJson = JSON.stringify({ "minecraft:keep_on_death": {} });
  const dataValue = damage !== undefined ? damage : 0;
  player.runCommand(
    `replaceitem entity @s slot.hotbar ${slotIndex} ${typeId} ${amount} ${dataValue} ${componentJson}`
  );

  const inventory = player.getComponent("minecraft:inventory");
  const container = inventory.container;
  const newItem = container.getItem(slotIndex);

  if (!newItem) {
    player.sendMessage("§cSomething went wrong applying Keep Inventory.");
    return;
  }

  if (nameTag) {
    newItem.nameTag = nameTag;
  }

  const newEnchantableComp = newItem.getComponent(ItemComponentTypes.Enchantable);
  if (newEnchantableComp && enchantments.length > 0) {
    newEnchantableComp.addEnchantments(enchantments);
  }

  newItem.setLore([...lore, LORE_TAG]);
  container.setItem(slotIndex, newItem);

  // Deduct 20 XP levels
  player.runCommand(`xp -${XP_COST}L @s`);

  player.playSound("random.levelup", { pitch: 1.2, volume: 0.6 });
  player.sendMessage("§d✦ Keep Inventory has been applied to your item!");
}
